#ifndef SHELL_HPP
#define SHELL_HPP

#include "tree.hpp"  

int mainShell(FsTree& fs);

#endif